package org.practice;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class JdbcServletClass
 */
@WebServlet(urlPatterns="/hereUgo")
public class JdbcServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JdbcServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("in-doGet() request.getContextPath():  "+request.getContextPath());
		
		String userName = request.getParameter("userName");
        String password = request.getParameter("password");
		
        UserAccount userAccount=null;
        RequestDispatcher requestDispatcher=null;
        if(userName != null || password != null
                || userName.length() != 0 || password.length() != 0){
        	try {
				Connection conn = DbConnection.getMySQLConnection();
				System.out.println("connected to database.......");
				userAccount=MyDbUtility.findUser(conn, userName, password);
				if(userAccount!=null){
					/**
					 * 1. request.setAttribute("user", userAccount);
					 * this is important to setAttribute if we want to access the userAccount object
					 * variable in our jsp page but in jsp we use the key "user"*/
					request.setAttribute("user", userAccount);
					
					System.out.println("user details fetched :: "+ userAccount);
					requestDispatcher=getServletContext().getRequestDispatcher("/views/welcome.jsp");
					requestDispatcher.forward(request, response);
					
					/**we can access WEB-INF through RD not through sendRe() because 
					 * sendRe() generates new request i.e made by browser and
					 * user is not allowed to access WEB-INF */
					//requestDispatcher=getServletContext().getRequestDispatcher("/WEB-INF/views/welcome.jsp");
					//requestDispatcher.include(request, response);
					
				}
				else{
					/*requestDispatcher=getServletContext().getRequestDispatcher("/WEB-INF/view/error.html");
					requestDispatcher.forward(request, response);*/
					//or
					//requestDispatcher.include(request, response);
					
					System.out.println("incorrect entry.......");
					response.sendRedirect(request.getContextPath()+"/views/error.html");
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        else{
        	System.out.println("please fill the required fields");
        	response.sendRedirect(request.getContextPath()+"/views/error.html");
        }
        
	}



}
