/**
 * 
 */
package org.practice.model;

import java.io.Serializable;

/**
 * @author thinktalent17
 *
 */
public class UserInfo implements Serializable {

	private Integer userId;
	private String name;
	private Integer password;
	private String email;
	//private String userType;

	public UserInfo( Integer userId, String name, String email,Integer password) {
		this.userId=userId;
		this.name=name;
		this.email=email;
		this.password=password;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPassword() {
		return password;
	}

	public void setPassword(Integer password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
}
