package practice;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CallerServlet1
 */
@WebServlet("/call1")
public class CallerServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CallerServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		/*
		 * NOTE : 
		 * 1. to call this servlet after default.html write /call1 in url
		 * 2. if default.html is at root dir and any servlet also have urlPattern="/"
		   then this will lead to conflicts like infinite loop etc.
		   As initially tomcat have to show the file at default path and default urlPattern
		   which will lead to multiple 
		*/
		
		
		/**REQUEST-DISPATCHER*/
		//request.getRequestDispatcher("default.html").forward(request, response);
		request.getRequestDispatcher("/views/outView.html").forward(request, response);
		//request.getRequestDispatcher("/WEB-INF/checkIn.html").forward(request, response);
		//request.getRequestDispatcher("/WEB-INF/views/inView.html").forward(request, response);
		
		
		/**SEND-REDIRECT*/
		//response.sendRedirect("default.html");
		//response.sendRedirect(request.getContextPath()+"/views/outView.html");
		/** 
		 * You can't redirect to resources inside WEB-INF. 
		 * All resources in that directory are non-visible to the browser, by design.
		 * Either keep the JSP outside of WEB-INF, or add a servlet which forwards to the JSP, 
		 * and redirect to the servlet instead.
		 * */
		//response.sendRedirect(request.getContextPath()+"/WEB-INF/checkIn.html");
		//response.sendRedirect(request.getContextPath()+"/WEB-INF/views/inView.html");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
